"""GTO-floor advisor (#39 flop, #41 turn): loads the trained MLPs (advisor.pt = flop donk/c-bet,
turn_advisor.pt = turn lead/barrel; from extraction/train_advisor.py + train_turn_advisor.py) and predicts the
solver's P(bet) for a hand at that node, from blocker/potential features. bot.py uses it for the per-hand bet
decision (frequency AND hand-selection). Pure glue over EXISTING solver data; falls back to None (-> heuristic
floor) if torch or the model is absent. Each net is street-specific (flop net valid on the flop, turn on the turn).
"""
from __future__ import annotations

import os

from pokerbot import config
from pokerbot.engine.evaluator import evaluate
from pokerbot.strategy.features import RANKS, hand_features

TIERS = ["air", "medium", "strong"]
TEX = ["high", "low", "connected", "monotone", "paired"]
BOOLS = ["flush_draw", "backdoor_flush", "nut_flush_blocker", "made_straight", "oesd", "gutshot", "has_draw"]
_STREETS = ["flop", "turn", "river"]   # defense-advisor street one-hot (matches train_defense_advisor.feat)
_FILES = {"flop": "advisor.pt", "turn": "turn_advisor.pt", "river": "river_advisor.pt",
          "river_la": "river_advisor_la.pt"}
_NETS: dict = {}
_TORCH = None

# Line-aware river advisor (POKERB_RIVER_LA, default OFF -> the old river_advisor.pt path = product unchanged). When
# ON + a pot_type is supplied, p_bet routes the river to river_advisor_la.pt (21-dim: + pot-type one-hot) so it can
# value-bet correctly per range (the under-value-betting fix; the micro-test: P_bet swings 17%->97% with the range).
from pokerbot.strategy.gto_mode import flag as _flag   # import-order-safe (GTOW-mode profile aware)
RIVER_LA = _flag("POKERB_RIVER_LA", "0") == "1"
POT_TYPES = ["srp", "3bet", "4bet"]      # one-hot order — MUST match research/train_river_la.POT_TYPES


def _texture(board) -> str:
    from pokerbot.strategy.postflop import classify_board
    t = classify_board(board)
    if t.get("paired"):
        return "paired"
    if t.get("monotone"):
        return "monotone"
    if t.get("connected"):
        return "connected"
    return "high" if board and max(RANKS.index(c[0]) for c in board) >= RANKS.index("T") else "low"


def _vector(f, role, tex, strength) -> list:
    v = [1.0 if f["tier"] == t else 0.0 for t in TIERS]
    v += [1.0 if tex == t else 0.0 for t in TEX]
    v.append(1.0 if role == "IP" else 0.0)
    v += [1.0 if f[k] else 0.0 for k in BOOLS]
    v.append(f["overcards"] / 2.0)
    v.append(float(strength))
    return v


def _load(street: str = "flop"):
    """Load (and cache) the street's advisor MLP; False if torch / the model file is unavailable."""
    global _TORCH
    if street not in _NETS:
        try:
            import torch
            import torch.nn as nn
            _TORCH = torch
            ck = torch.load(config.KNOWLEDGE_DIR / "postflop" / _FILES[street], map_location="cpu")
            d = ck["dims"]
            net = nn.Sequential(nn.Linear(d, 64), nn.ReLU(), nn.Linear(64, 64), nn.ReLU(),
                                nn.Linear(64, 1), nn.Sigmoid())
            net.load_state_dict(ck["state"])
            net.eval()
            _NETS[street] = net
        except Exception:  # noqa: BLE001
            _NETS[street] = False
    return _NETS[street]


def available(street: str = "flop") -> bool:
    return bool(_load(street))


# CLEANUP 2026-07-05 (profiled: p_bet = 57% of decide() runtime at 196k calls — the range tracker queries it
# per combo per action, and the same (combo, board, street) recurs across a hand's walk): both query functions
# are pure per their full argument tuple + fixed module state (nets load once, RIVER_LA reads once at import),
# so results are memoized. Bounded dicts, cleared wholesale when full.
_PBET_MEMO: dict = {}
_PDEF_MEMO: dict = {}
_MEMO_MAX = 120_000


def p_bet(hole, board, role, street: str = "flop", pot_type: str | None = None) -> float | None:
    """Advisor P(bet) for this hand at the flop (OOP=donk / IP=c-bet), turn (OOP=lead / IP=barrel) or river node;
    None -> caller falls back to the heuristic floor. When RIVER_LA is ON and a pot_type is given, the river routes
    to the line-aware net river_advisor_la.pt (21-dim: + pot-type one-hot) = the under-value-betting fix."""
    key = (tuple(hole), tuple(board), role, street, pot_type)
    if key in _PBET_MEMO:
        return _PBET_MEMO[key]
    if len(_PBET_MEMO) >= _MEMO_MAX:
        _PBET_MEMO.clear()
    result = _p_bet_compute(hole, board, role, street, pot_type)
    _PBET_MEMO[key] = result
    return result


def _p_bet_compute(hole, board, role, street, pot_type) -> float | None:
    strength = 1.0 - evaluate(board, hole) / 7462.0
    f = hand_features(hole, board)
    if street == "river" and RIVER_LA and pot_type is not None and _load("river_la"):
        v = _vector(f, role, _texture(board), strength) + [1.0 if pot_type == p else 0.0 for p in POT_TYPES]
        x = _TORCH.tensor([v], dtype=_TORCH.float32)
        with _TORCH.no_grad():
            return float(_load("river_la")(x)[0, 0].item())
    net = _load(street)
    if not net:
        return None
    x = _TORCH.tensor([_vector(f, role, _texture(board), strength)], dtype=_TORCH.float32)
    with _TORCH.no_grad():
        return float(net(x)[0, 0].item())


def p_bet_batch(combos, board, role, street: str = "flop", pot_type: str | None = None) -> dict:
    """Batched Advisor-P(bet): EIN Forward-Pass fuer viele Combos statt N Batch-1-Passes
    (gemessen 2026-08-16: 107k Batch-1-Passes in 30 Decks = die heisseste Schleife des
    Gates). Liest UND fuellt dasselbe Memo wie p_bet -> beide Pfade teilen eine Cache-
    Sicht. river_la-Pfad (pot_type) faellt auf Einzelaufrufe zurueck (selten, Paritaet)."""
    out: dict = {}
    todo = []
    for c in combos:
        key = (tuple(c), tuple(board), role, street, pot_type)
        if key in _PBET_MEMO:
            out[tuple(c)] = _PBET_MEMO[key]
        else:
            todo.append(c)
    if not todo:
        return out
    if street == "river" and RIVER_LA and pot_type is not None:
        for c in todo:
            out[tuple(c)] = p_bet([c[0], c[1]], board, role, street, pot_type)
        return out
    net = _load(street)
    if not net:
        for c in todo:
            _PBET_MEMO[(tuple(c), tuple(board), role, street, pot_type)] = None
            out[tuple(c)] = None
        return out
    tex = _texture(board)
    rows = []
    for c in todo:
        hole = [c[0], c[1]]
        strength = 1.0 - evaluate(board, hole) / 7462.0
        rows.append(_vector(hand_features(hole, board), role, tex, strength))
    x = _TORCH.tensor(rows, dtype=_TORCH.float32)
    with _TORCH.no_grad():
        ys = net(x)[:, 0]
    if len(_PBET_MEMO) >= _MEMO_MAX:
        _PBET_MEMO.clear()
    for c, y in zip(todo, ys):
        v = float(y.item())
        _PBET_MEMO[(tuple(c), tuple(board), role, street, pot_type)] = v
        out[tuple(c)] = v
    return out


# ---- MVP C2: facing-bet DEFENSE advisor (3-output fold/call/raise; trained by extraction/train_defense_advisor) ----
_DEF: dict = {}


def _load_defense():
    """Load (and cache) the facing-bet defense advisor MLP (3-output fold/call/raise); False if torch/file absent."""
    global _TORCH
    if "net" not in _DEF:
        try:
            import torch
            import torch.nn as nn
            _TORCH = torch
            ck = torch.load(config.KNOWLEDGE_DIR / "postflop" / "defense_advisor.pt", map_location="cpu")
            net = nn.Sequential(nn.Linear(ck["dims"], 64), nn.ReLU(), nn.Linear(64, 64), nn.ReLU(),
                                nn.Linear(64, 3))
            net.load_state_dict(ck["state"])
            net.eval()
            _DEF["net"] = net
        except Exception:  # noqa: BLE001
            _DEF["net"] = False
    return _DEF["net"]


def defense_available() -> bool:
    return bool(_load_defense())


def p_defense(hole, board, role, size_faced: float, street: str = "flop"):
    """Solver (P_fold, P_call, P_raise) for this hand facing a bet of size_faced (× the pot it was bet into) on
    `street`, or None -> caller uses the heuristic. Trained on the flop+turn+river caches (turn added 2026-06-16)
    -> the caller gates to those streets. Feature vector EXACTLY matches extraction/train_defense_advisor.feat: tier, texture(flop), STREET,
    role, bools, overcards, strength, size_faced. Texture is keyed on the flop (board[:3]) as in build_defense_data.
    Memoized (pure per full argument tuple; the range tracker calls per combo)."""
    key = (tuple(hole), tuple(board), role, size_faced, street)
    if key in _PDEF_MEMO:
        return _PDEF_MEMO[key]
    if len(_PDEF_MEMO) >= _MEMO_MAX:
        _PDEF_MEMO.clear()
    result = _p_defense_compute(hole, board, role, size_faced, street)
    _PDEF_MEMO[key] = result
    return result


def _p_defense_compute(hole, board, role, size_faced, street):
    net = _load_defense()
    if not net:
        return None
    f = hand_features(hole, board)
    tex = _texture(board[:3])
    strength = 1.0 - evaluate(board, hole) / 7462.0
    v = [1.0 if f["tier"] == t else 0.0 for t in TIERS]
    v += [1.0 if tex == t else 0.0 for t in TEX]
    v += [1.0 if street == s else 0.0 for s in _STREETS]
    v.append(1.0 if role == "IP" else 0.0)
    v += [1.0 if f[k] else 0.0 for k in BOOLS]
    v.append(f["overcards"] / 2.0)
    v.append(float(strength))
    v.append(float(size_faced))
    x = _TORCH.tensor([v], dtype=_TORCH.float32)
    with _TORCH.no_grad():
        p = _TORCH.softmax(net(x), dim=1)[0]
    return float(p[0]), float(p[1]), float(p[2])


def p_defense_batch(combos, board, role, size_faced: float, street: str = "flop") -> dict:
    """v10/K1 (E11, additiv): gebatchtes (P_fold, P_call, P_raise) fuer viele Combos in EINEM Forward-Pass —
    das Gegenstueck zu p_bet_batch fuer den Defense-Advisor (V10_FAKTEN A4: 68-70 ms je Voll-Range einzeln).
    KEINE Gewichts-/Feature-Aenderung: die Feature-Zeile ist Zeile fuer Zeile _p_defense_compute, dasselbe Netz,
    dieselbe Softmax; liest UND fuellt dasselbe Memo wie p_defense (eine Cache-Sicht). Die Identitaet Einzelpfad
    == Batch (1e-6) bewacht tests/test_hero_range.py. Ergebnis: {combo(tuple): (pf, pc, pr) | None}."""
    out: dict = {}
    todo = []
    for c in combos:
        key = (tuple(c), tuple(board), role, size_faced, street)
        if key in _PDEF_MEMO:
            out[tuple(c)] = _PDEF_MEMO[key]
        else:
            todo.append(c)
    if not todo:
        return out
    net = _load_defense()
    if len(_PDEF_MEMO) >= _MEMO_MAX:
        _PDEF_MEMO.clear()
    if not net:
        for c in todo:
            _PDEF_MEMO[(tuple(c), tuple(board), role, size_faced, street)] = None
            out[tuple(c)] = None
        return out
    tex = _texture(board[:3])                      # Textur am FLOP-Board, wie _p_defense_compute
    rows = []
    for c in todo:
        hole = [c[0], c[1]]
        f = hand_features(hole, board)
        strength = 1.0 - evaluate(board, hole) / 7462.0
        v = [1.0 if f["tier"] == t else 0.0 for t in TIERS]
        v += [1.0 if tex == t else 0.0 for t in TEX]
        v += [1.0 if street == s else 0.0 for s in _STREETS]
        v.append(1.0 if role == "IP" else 0.0)
        v += [1.0 if f[k] else 0.0 for k in BOOLS]
        v.append(f["overcards"] / 2.0)
        v.append(float(strength))
        v.append(float(size_faced))
        rows.append(v)
    x = _TORCH.tensor(rows, dtype=_TORCH.float32)
    with _TORCH.no_grad():
        ps = _TORCH.softmax(net(x), dim=1)
    for c, p in zip(todo, ps):
        triple = (float(p[0].item()), float(p[1].item()), float(p[2].item()))
        _PDEF_MEMO[(tuple(c), tuple(board), role, size_faced, street)] = triple
        out[tuple(c)] = triple
    return out
